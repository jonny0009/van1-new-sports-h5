<template>
  <router-view />
</template>
<style scoped>
:root {
  --van-toast-text-padding: 20px 30px;
  --van-toast-font-size: 28px;
}

  .noData {
  text-align: center;
  font-family: PingFangSC-Medium;
  font-size: 24px;
  color: #96A5AA;
  letter-spacing: 0;
  font-weight: 500;

   > .img_1 {
    margin-top: 331px;
    width: 102px;
    height: 121px;
    margin-bottom: 57px;

  }
}
</style>
