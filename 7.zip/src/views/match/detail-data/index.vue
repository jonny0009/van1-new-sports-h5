<template>
  <div class="panel-data">
    <MatchDatabase />
  </div>
</template>

<script setup lang="ts">
import MatchDatabase from '@/components/Match/database/index.vue'
</script>

<style lang="scss" scoped>
.panel-data {
  padding: 20px 0;
}
</style>
