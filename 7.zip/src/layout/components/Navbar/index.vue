<template>
  <div class="navbar">
    头部
  </div>
</template>

<script lang="ts" setup>

</script>

<style lang="scss" scoped>
.navbar {
  height: 50px;
  padding: 0 20px;
  overflow: hidden;
  line-height: 50px;
}
</style>
