<template>
  <div class="empty-icon"></div>
</template>
<script lang="ts" setup>
</script>
<style lang="scss" scoped>
  .empty-icon {
    width: 175px;
    height: 175px;
    background-size: contain;
    background-repeat: no-repeat;
    background-position: center;
    background-image: url('@/assets/images/betting/empty.png');
  }
</style>
