import home from './home'
import betting from './betting'
import user from './user'
import sport from './sport'
import live from './live'

export default {
  home,
  user,
  betting,
  sport,
  live
}
